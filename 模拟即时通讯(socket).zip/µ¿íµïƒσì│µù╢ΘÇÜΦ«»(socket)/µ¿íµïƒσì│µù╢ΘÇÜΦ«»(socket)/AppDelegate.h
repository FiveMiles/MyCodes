//
//  AppDelegate.h
//  模拟即时通讯(socket)
//
//  Created by jason on 25/10/16.
//  Copyright © 2016年 Jason. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

