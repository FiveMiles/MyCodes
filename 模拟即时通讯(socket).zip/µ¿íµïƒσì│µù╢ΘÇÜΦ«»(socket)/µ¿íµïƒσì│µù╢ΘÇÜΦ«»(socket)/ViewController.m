//
//  ViewController.m
//  模拟即时通讯(socket)
//
//  Created by jason on 25/10/16.
//  Copyright © 2016年 Jason. All rights reserved.
//

#import "ViewController.h"
#import <sys/socket.h>
#import <netinet/in.h>
#import <arpa/inet.h>

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UILabel *ipView;
@property (weak, nonatomic) IBOutlet UILabel *portView;



@property (weak, nonatomic) IBOutlet UITextField *inputView;
@property (weak, nonatomic) IBOutlet UITextField *outputView;
@property(nonatomic,assign)int clientSocket;

@end
#define UserIP @"127.0.0.1"
#define UserPort @"12345"

@implementation ViewController
- (IBAction)connect:(id)sender {
    int port = self.portView.text.intValue;
    const char * ip = self.ipView.text.UTF8String;
    
    int clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    self.clientSocket = clientSocket;
    
    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = inet_addr(ip);
    int result = connect(clientSocket, (const struct sockaddr *)&addr, sizeof(addr));
    
    if (result == 0) {
        NSLog(@"Connect success!");
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            uint8_t buffer[1024];
            while (YES) {
                ssize_t recLen = recv(self.clientSocket, buffer, sizeof(buffer), 0);
                NSLog(@"Receive byte : %zd",recLen);
                
                NSString * recMsg = [[NSString alloc]initWithBytes:buffer length:recLen encoding:NSUTF8StringEncoding];
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.outputView.text = recMsg;
                });
            }
        });
    } else {
        NSLog(@"Connect falied!");
    }
}
- (IBAction)close:(id)sender {
    close(self.clientSocket);
}
- (IBAction)send:(id)sender {
    const char * msg = self.inputView.text.UTF8String;
    ssize_t sendLen = send(self.clientSocket, msg, strlen(msg), 0);
    NSLog(@"Send bytes : %zd",sendLen);
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor cyanColor];
    self.ipView.text = UserIP;
    self.portView.text = UserPort;
}


@end
