//
//  SQLiteManager.h
//  操作数据库OC
//
//  Created by jason on 20/10/16.
//  Copyright © 2016年 Jason. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SQLiteManager : NSObject

+(instancetype)shareInstance;

-(BOOL)openDB;

-(BOOL)execSQL:(NSString *)sql;

-(NSArray *)querrySQL:(NSString *)querySQL;



@end
