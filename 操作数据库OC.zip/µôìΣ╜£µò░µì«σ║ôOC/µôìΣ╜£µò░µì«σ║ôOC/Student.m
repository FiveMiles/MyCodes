//
//  Student.m
//  操作数据库OC
//
//  Created by jason on 20/10/16.
//  Copyright © 2016年 Jason. All rights reserved.
//

#import "Student.h"
#import "SQLiteManager.h"
@implementation Student

-(instancetype)initWithName:(NSString *)name age:(NSInteger)age
{
    if (self = [super init]) {
        self.name = name;
        self.age = age;
    }
    return self;
}
-(instancetype)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

-(void)insertStudent
{
    NSString * insertSQL = [NSString stringWithFormat:@"insert into t_student (name,age)values('%@',%ld);",self.name,self.age];
    if ([[SQLiteManager shareInstance] execSQL:insertSQL]) {
        NSLog(@"数据插入成功！");
    }
}

+(NSArray *)loadData
{
    NSString * querySQL = @"SELECT name, age FROM t_student;";
    NSArray * dictArray = [[SQLiteManager shareInstance] querrySQL:querySQL];
    
    NSMutableArray * tempArray = [NSMutableArray array];
    for (NSDictionary * dict in dictArray) {
        [tempArray addObject:[[Student alloc]initWithDict:dict]];
    }
    return tempArray;
}

@end
