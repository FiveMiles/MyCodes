//
//  ViewController.m
//  操作数据库OC
//
//  Created by jason on 20/10/16.
//  Copyright © 2016年 Jason. All rights reserved.
//

#import "ViewController.h"
#import "SQLiteManager.h"
#import "Student.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
//    for(int i = 0; i < 20 ; i++){
//        NSString * name = [NSString stringWithFormat:@"asd%d",arc4random_uniform(20)];
//        NSInteger age = arc4random_uniform(20);
//        Student * stu = [[Student alloc]initWithName:name age:age];
//        [stu insertStudent];
//    }
    NSArray * stus = [Student loadData];
    NSLog(@"%@",stus);
}

@end
