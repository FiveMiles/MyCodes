//
//  SQLiteManager.m
//  操作数据库OC
//
//  Created by jason on 20/10/16.
//  Copyright © 2016年 Jason. All rights reserved.
//

#import "SQLiteManager.h"
#import <sqlite3.h>

@interface SQLiteManager ()

@property(nonatomic,assign)sqlite3 * db;

@end


@implementation SQLiteManager

+(instancetype)shareInstance
{
    static id instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc]init];
    });
    return instance;
}

-(BOOL)openDB
{
    NSString * filePath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    filePath = [filePath stringByAppendingPathComponent:@"demo.sqlite"];
    
    if (sqlite3_open(filePath.UTF8String, &_db) != SQLITE_OK) {
        NSLog(@"数据库打开失败");
        return NO;
    }
    return [self createTable];
}

-(BOOL)createTable
{
    NSString * createTableSQL = @"CREATE TABLE IF NOT EXISTS 't_student' ( 'id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,'name' TEXT,'age' INTEGER);";
    return [self execSQL:createTableSQL];
}

-(BOOL)execSQL:(NSString *)sql
{
    return sqlite3_exec(self.db, sql.UTF8String, nil, nil, nil) == SQLITE_OK;
}

-(NSArray *)querrySQL:(NSString *)querySQL
{
    sqlite3_stmt * stmt = nil;
    if (sqlite3_prepare_v2(self.db, querySQL.UTF8String, -1, &stmt, nil) != SQLITE_OK) {
        NSLog(@"查询失败");
        return nil;
    }
    
    NSMutableArray * dictArray = [NSMutableArray array];
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        int count = sqlite3_column_count(stmt);
        
        NSMutableDictionary * dict = [NSMutableDictionary dictionary];
        for (int i = 0; i < count; i++) {
            const char *cKey = sqlite3_column_name(stmt, i);
            NSString * key = [NSString stringWithUTF8String:cKey];
            
            const char * cValue = (const char *)sqlite3_column_text(stmt, i);
            NSString * value = [NSString stringWithUTF8String:cValue];
            
            [dict setValue:value forKey:key];
        }
        [dictArray addObject:dict];
    }
    return dictArray;
}
@end
