//
//  Student.h
//  操作数据库OC
//
//  Created by jason on 20/10/16.
//  Copyright © 2016年 Jason. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Student : NSObject

@property(nonatomic,copy)NSString * name;
@property(nonatomic,assign)NSInteger age;

-(instancetype)initWithName:(NSString *)name age:(NSInteger)age;
-(instancetype)initWithDict:(NSDictionary *)dict;

-(void)insertStudent;

+(NSArray *)loadData;

@end
