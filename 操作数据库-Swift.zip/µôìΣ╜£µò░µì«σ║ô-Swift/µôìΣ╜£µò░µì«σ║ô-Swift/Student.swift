//
//  Student.swift
//  操作数据库-Swift
//
//  Created by jason on 20/10/16.
//  Copyright © 2016年 Jason. All rights reserved.
//

import UIKit

class Student: NSObject {
    var name : String?
    var age : Int = 0
    init(name : String, age : Int) {
        self.name = name
        self.age = age
    }
    
    init(dict : [String : AnyObject]) {
        super.init()
        self.setValuesForKeys(dict)
    }
    func insertStudent() {
        let insertSQL = "INSERT INTO t_student (name, age) VALUES ('\(name!)',\(age));"
        if SQLiteManager.shareInstance().execSQL(sql: insertSQL) {
            print("插入数据成功")
        }
    }
    class func loadData() -> [Student]? {
        let querySql = "SELECT name, age FROM t_student;"
        let dictArray = SQLiteManager.shareInstance().query(querySql)
        
        if let tempDictArray = dictArray {
            var tempArray = [Student]()
            for dict in tempDictArray {
                tempArray.append(Student(dict: dict))
            }
            return tempArray
        }
        return nil
    }
}
