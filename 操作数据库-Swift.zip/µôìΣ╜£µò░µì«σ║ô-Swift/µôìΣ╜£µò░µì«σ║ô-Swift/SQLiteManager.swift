//
//  SQLiteManager.swift
//  操作数据库-Swift
//
//  Created by jason on 20/10/16.
//  Copyright © 2016年 Jason. All rights reserved.
//

import UIKit

class SQLiteManager: NSObject {
    static let instance = SQLiteManager()
    class func shareInstance() -> SQLiteManager {
        return instance
    }
    
    var db : OpaquePointer? = nil
    
    func openDB() -> Bool {
        let filePath = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true).first
        let file = (filePath! as NSString).appendingPathComponent("test.sqlite")
        let cFile = (file.cString(using: String.Encoding.utf8))!
        
        if sqlite3_open(cFile, &db) != SQLITE_OK {
            print("打开数据库失败")
            return false
        }
        return createTable()
    }
    
    func createTable() -> Bool {
        let createTableSQL = "CREATE TABLE IF NOT EXISTS 't_student' ( 'id' INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,'name' TEXT,'age' INTEGER);"
        return execSQL(sql: createTableSQL)
    }
    func execSQL( sql : String) -> Bool {
        
        let cSql = (sql.cString(using: String.Encoding.utf8))!
        
        let isok = sqlite3_exec(db, cSql, nil, nil, nil) == SQLITE_OK
        print(isok)
        return isok
    }
    func query(_ querySql : String) -> [[String : AnyObject]]? {
        var stmt : OpaquePointer? = nil
        let cQuerySQL = (querySql.cString(using: String.Encoding.utf8))!
        if sqlite3_prepare_v2(db, cQuerySQL, -1, &stmt, nil) != SQLITE_OK {
            print("没有准备好")
            return nil
        }
        
        var tempArray = [[String : AnyObject]]()
        while sqlite3_step(stmt) == SQLITE_ROW {
            let count = sqlite3_column_count(stmt)
            
            var dict = [String : AnyObject]()
            for i in 0..<count {
                let ckey = sqlite3_column_name(stmt, i)
                let key = String(cString: ckey!, encoding: String.Encoding.utf8)
                
                let cvalue = sqlite3_column_text(stmt, i)
                
                let value = String(cString: "\(cvalue!)", encoding: String.Encoding.utf8)
                dict[key!] = value as AnyObject?
            }
            tempArray.append(dict)
        }
        
        return tempArray
    }
}
