//
//  ViewController.swift
//  操作数据库-Swift
//
//  Created by jason on 20/10/16.
//  Copyright © 2016年 Jason. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
       
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
//        let stu = Student(name: "wjehg", age: 13)
//        stu.insertStudent()
        let array = Student.loadData()
        //print(array)
    }


}

