//
//  ViewController.m
//  TestDoubleTableViews
//
//  Created by jason on 7/11/16.
//  Copyright © 2016年 Jason. All rights reserved.
//

#import "ViewController.h"
#import "CustomCell.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate>

//第一个UITableView
@property(nonatomic,strong)UIScrollView * scrollView;

@property(nonatomic,strong)UITableView * tableView;

@property(nonatomic,strong)NSMutableArray * dataSourceOne;

@end

#define Width   self.view.frame.size.width
#define Height   self.view.frame.size.height

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self.view addSubview:self.scrollView];
    
    UIView * oneView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, Width, 200)];
    oneView.backgroundColor = [UIColor blackColor];
    [self.scrollView addSubview:oneView];
    
    UITableView * tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 200, Width, 300) style:UITableViewStylePlain];
    tableView.delegate = self.scrollView;
    tableView.dataSource = self;
    self.tableView = tableView;
    [self.scrollView addSubview:self.tableView];
    
    for (NSInteger i = 0; i < 8; i ++) {
        UIColor * cusColor = [UIColor colorWithRed:arc4random_uniform(255)/255.0 green:arc4random_uniform(255)/255.0 blue:arc4random_uniform(255)/255.0 alpha:1.0];
        UIView * twoView = [[UIView alloc]initWithFrame:CGRectMake(0, 500 + i * 200, Width, 200)];
        twoView.backgroundColor = cusColor;
        [self.scrollView addSubview:twoView];
    }
}
-(UIScrollView *)scrollView
{
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc]initWithFrame:self.view.bounds];
        _scrollView.delegate = self;
        _scrollView.contentSize = CGSizeMake(Width, Height*3);
        _scrollView.backgroundColor = [UIColor greenColor];
        //_scrollView.contentOffset = CGPointMake(0, 0);
    }
    return _scrollView;
}
-(NSMutableArray *)dataSourceOne
{
    if (!_dataSourceOne) {
        _dataSourceOne = [NSMutableArray arrayWithObjects:@1,@2,@1,@5,@6,@7,@8,@9,@10,@11,@12,@13, nil];
    }
    return _dataSourceOne;
}

#pragma mark -- UITableView delegate & datasource

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataSourceOne.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
        static NSString * ID = @"cellone";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
        if (!cell) {
            cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
        }
        cell.textLabel.text = [NSString stringWithFormat:@"textLabel---%ld",indexPath.row];
        return cell;
}

-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}
-(UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;
}
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [_dataSourceOne removeObjectAtIndex:indexPath.row];
    [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    [tableView reloadData];
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 3) {
        NSIndexPath * path = [NSIndexPath indexPathForRow:9 inSection:0];
        [self.tableView scrollToRowAtIndexPath:path atScrollPosition:UITableViewScrollPositionBottom animated:YES];
    }
}

-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    NSLog(@"%f",scrollView.contentOffset.y);
}


@end
