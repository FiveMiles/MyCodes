//
//  CustomCell.h
//  TestDoubleTableViews
//
//  Created by jason on 7/11/16.
//  Copyright © 2016年 Jason. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol TableViewTwoScrollToBottomDelegate <NSObject>

-(void)whenTableViewTwoScrollToBottm;

@end

@interface CustomCell : UITableViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier superTableView:(UITableView *)superTableView dataSource:(NSMutableArray *)dataSource frame:(CGRect)frame;

@property(nonatomic,weak)id <TableViewTwoScrollToBottomDelegate> customDelegate;


@end
