//
//  CusView.m
//  TestDoubleTableViews
//
//  Created by jason on 7/11/16.
//  Copyright © 2016年 Jason. All rights reserved.
//

#import "CusView.h"

@implementation CusView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
