//
//  CustomCell.m
//  TestDoubleTableViews
//
//  Created by jason on 7/11/16.
//  Copyright © 2016年 Jason. All rights reserved.
//

#import "CustomCell.h"

@interface CustomCell ()<UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate>
//第二个TableView。
@property(nonatomic,strong)UITableView * tableViewTwo;
@property(nonatomic,strong)NSMutableArray * dataSourceTwo;
@end

@implementation CustomCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier superTableView:(UITableView *)superTableView dataSource:(NSMutableArray *)dataSource frame:(CGRect)frame
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.dataSourceTwo = dataSource;
        self.tableViewTwo.frame = frame;
        [self configSubViews];
    }
    return self;
}

-(void)configSubViews
{
    [self addSubview:self.tableViewTwo];
    
    
    
}

-(UITableView *)tableViewTwo
{
    if (!_tableViewTwo) {
        _tableViewTwo = [[UITableView alloc]initWithFrame:self.bounds style:UITableViewStylePlain];
        _tableViewTwo.delegate = self;
        _tableViewTwo.dataSource = self;
        
    }
    return _tableViewTwo;
}
-(NSMutableArray *)dataSourceTwo
{
    if (!_dataSourceTwo ) {
        _dataSourceTwo = [NSMutableArray array];
    }
    return _dataSourceTwo;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataSourceTwo.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * ID = @"cellTwo";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
    }
    cell.textLabel.text = [NSString stringWithFormat:@"textLabel---%ld",indexPath.row];
    cell.contentView.backgroundColor = [UIColor cyanColor];
    return cell;
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    NSLog(@"%f",scrollView.contentOffset.y);
    if (scrollView.contentOffset.y > 328) {
        if ([self.customDelegate respondsToSelector:@selector(whenTableViewTwoScrollToBottm)]) {
            [self.customDelegate whenTableViewTwoScrollToBottm];
        }
    }
}
@end
